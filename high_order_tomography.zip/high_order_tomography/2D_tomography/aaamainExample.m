% 1st order
clc; clear; close all
tic
format long

%% parameter settings
tol = 0.001;
kmax = 30000;
N = 129;
h = 1/(N-1);

num = 10;
len = h*num;
x_axis = [-1, 1];
y_axis = [-1, 1];
x = linspace(x_axis(1), x_axis(2), N);
y = linspace(y_axis(1), y_axis(2), N);
[X, Y] = meshgrid(x, y);

%% examples
c_exact = 3 - 2.5 * exp(-X.^2 / 2);
% c_exact = ones(N);
% c_exact = 3 - (1/2)*exp(-(X.^2 + (Y-0.5).^2)/0.5.^2) - exp(-(X.^2 + (Y-1.25).^2)/0.5.^2);
% load c_data/example_3

%% source point
% fixed_pt_list = [0, 65, 45];
% fixed_pt_list = [0, 51, 51]; 
fixed_pt_list = [];
for m = 1:4
    for n = 1:4
        fixed_pt_list = [fixed_pt_list; 0, m*25, n*25];
    end
end
% for m = 1:10
%     for n = 1:10
%         fixed_pt_list = [fixed_pt_list; 0, m*12, n*12];
%     end
% end    

%% iteration
I = N;
J = N;
dx = (x(end)-x(1)) / (I-1); dy = (y(end) - y(1)) / (J-1);

niu = 1;
c0 = c_solver2(c_exact, zeros(I, J), dx, dy, niu);
c = c0;

T_star = cell(1, size(fixed_pt_list, 1));
parfor p_num = 1:size(fixed_pt_list, 1)

    T_star_temp = highOrderEikonalSolver_ext(c_exact, fixed_pt_list(p_num, :), dx, dy, X, Y);
    % T_star_temp = TravelTime_solver(c_exact, fixed_pt_list, dx, dy, I, J);
    T_star{p_num} = T_star_temp;


end


energy = 1e9;
alpha_f = 1e-6; alpha_0 = 0.5;
for k = 1: kmax
    
    energy_p = 0;
    cstar = 0;
    parfor p_num = 1:size(fixed_pt_list, 1)

        T = highOrderEikonalSolver_ext(c, fixed_pt_list(p_num, :), dx, dy, X, Y);
        % T = TravelTime_solver(c, fixed_pt_list(p_num, :), dx, dy, I, J);
        energy_p = energy_p + EnergyFun(T, T_star{p_num}, dx, dy);
        cstar = cstar + cStarSolver(T, T_star{p_num}, dx, I, J, c);

    end
    
    if energy_p < tol
        break
    end

    energy = [energy, energy_p];
    if mod(k, 1) == 0
       disp(k)
       disp(energy(k+1))
    end

        alpha = 0.01;
%     alpha = alpha_f + 0.5*(alpha_0 - alpha_f) * (1 + cos(pi*k / kmax));
    c = c + alpha * cstar;
end

%% results and visualization
norm(c-c_exact)*dx*dx

figure
subplot(2, 2, 1)
mesh(x, y, c_exact)
xlabel x
ylabel z
title('c_{exact}', 'FontWeight','bold')
subplot(2, 2, 2)
mesh(x, y, c0)
xlabel x
ylabel z
title('c_0', 'FontWeight','bold')
subplot(2, 2, 3)
mesh(x, y, c)
xlabel x
ylabel z
title('c_{solution}', 'FontWeight','bold')
subplot(2, 2, 4)
mesh(x, y, (c-c_exact)./c_exact)
title('Relative error')

figure
subplot(2, 2, 1)
plot(energy(2:end), 'linewidth', 1.5)
title('Energy')

subplot(2, 2, 2)
plot(y, c0(60, :), '-.', 'linewidth', 1.5)
hold on
plot(y, c(60, :), '--', 'linewidth', 1.5)
hold on
plot(y, c_exact(60, :), 'linewidth', 1.5)
legend('c_0', 'c_{numerical}', 'c_{exact}')
title('Cross-sections of the solutions: x = 0', 'FontWeight','bold')
set(gca, 'FontName','Times New Roman', 'FontSize',16, 'FontWeight','bold');

subplot(2, 2, 3)
plot(x, c0(:, 60), '-.', 'linewidth', 1.5)
hold on
plot(x, c(:, 60), '--', 'linewidth', 1.5)
hold on
plot(x, c_exact(:, 60), 'linewidth', 1.5)
legend('c_0', 'c_{numerical}', 'c_{exact}')
title('Cross-sections of the solutions: z = 0', 'FontWeight','bold')
set(gca, 'FontName','Times New Roman', 'FontSize',16, 'FontWeight','bold');


toc