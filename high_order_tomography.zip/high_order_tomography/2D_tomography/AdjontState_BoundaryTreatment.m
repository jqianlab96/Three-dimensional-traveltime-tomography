function lambda = AdjontState_BoundaryTreatment(lambda, T, T_star, c, dx, dy)

lambda_t = lambda;
[I, J] = size(lambda);
for i = 1:I
    T_x1 = (-11*T(i, 1)+18*T(i, 2)-9*T(i, 3)+2*T(i, 4)) / (6*dx);
    T_x2 = (-2*T(i, J-3)+9*T(i, J-2)-18*T(i, J-1)+11*T(i, J)) / (6*dx);
    lambda(i, 1) = (T_star(i, 1) - T(i, 1)) / (-T_x1);  % left
    lambda(i, J) = (T_star(i, J) - T(i, J)) / (T_x2);   % right
end
for j = 1:J
    T_y1 = (-11*T(1, j)+18*T(2, j)-9*T(3, j)+2*T(4, j)) / (6*dy);
    T_y2 = (-2*T(I-3, j)+9*T(I-2, j)-18*T(I-1, j)+11*T(I, j)) / (6*dy);
    lambda(1, j) = (T_star(1, j) - T(1, j)) / (-T_y1); % top
    lambda(I, j) = (T_star(I, j) - T(I, j)) / (T_y2); % bottom
end

N_t = 5;
[Tx, Ty] = weno_gradient(T, dx, dy);
[lambda_x, lambda_y] = weno_gradient(lambda, dx, dy);

% 1
tspan = (0:dx/N_t:dx)';
y = @(t,y) -((lambda_y(:, 2)-lambda_y(:, 1))/dx.*t+lambda_y(:, 1)) .* ((Ty(:, 2)-Ty(:, 1)).*t+Ty(:, 1))./((Tx(:, 2)-Tx(:, 1)).*t+Tx(:, 1));
[~,lambda_temp] = ode45(y, tspan, lambda(:, 1));
lambda(2:end-1, 2) = lambda_temp(end, 2:end-1);

% 2
tspan = (0:dy/N_t:dy)';
y = @(t,y) -((lambda_x(2, :)'-lambda_x(1, :)')/dy.*t+lambda_x(1, :)') .* ((Tx(2, :)'-Tx(1, :)').*t+Tx(1, :)')./((Ty(2, :)'-Ty(1, :)').*t+Ty(1, :)');
[~,lambda_temp] = ode45(y, tspan, lambda(1, :)');
lambda(2, 2:end-1) = lambda_temp(end, 2:end-1)';

% 3
tspan = (dx:-dx/N_t:0)';
y = @(t,y) -((lambda_y(:, end)-lambda_y(:, end-1))/dx.*t+lambda_y(:, end-1)) .* ((Ty(:, end)-Ty(:, end-1)).*t+Ty(:, end-1))./((Tx(:, end)-Tx(:, end-1)).*t+Tx(:, end-1));
[~,lambda_temp] = ode45(y, tspan, lambda(:, end));
lambda(2:end-1, end-1) = lambda_temp(end, 2:end-1);

% 4
tspan = (dy:-dy/N_t:0)';
y = @(t,y) -((lambda_x(end, :)'-lambda_x(end-1, :)')/dy.*t+lambda_x(end-1, :)') .* ((Tx(end, :)'-Tx(end-1, :)').*t+Tx(end-1, :)')./((Ty(end, :)'-Ty(end-1, :)').*t+Ty(end-1, :)');
[~,lambda_temp] = ode45(y, tspan, lambda(end, :)');
lambda(end-1, 2:end-1) = lambda_temp(end, 2:end-1)';


% exceptions
except = 0.005;
lambda(abs(lambda_t-lambda)>except) = lambda_t(abs(lambda_t-lambda)>except);


end