function [u_minus, u_plus] = WENO_5(um3, um2, um1, u, up1, up2, up3, h)

dp_um3 = um2 - um3;
dp_um2 = um1 - um2;
dp_um1 = u - um1;
dp_u = up1 - u;
dp_up1 = up2 - up1;
dp_up2 = up3 - up2;

dmdp_um2 = dp_um2 - dp_um3;
dmdp_um1 = dp_um1 - dp_um2;
dmdp_u = dp_u - dp_um1;
dmdp_up1 = dp_up1 - dp_u;
dmdp_up2 = dp_up2 - dp_up1;

u_minus = (-dp_um2/h + 7*dp_um1/h + 7*dp_u/h - dp_up1/h) / 12 - PhiWeno(dmdp_um2/h, dmdp_um1/h, dmdp_u/h, dmdp_up1/h);
u_plus = (-dp_um2/h + 7*dp_um1/h + 7*dp_u/h - dp_up1/h) / 12 + PhiWeno(dmdp_up2/h, dmdp_up1/h, dmdp_u/h, dmdp_um1/h);
