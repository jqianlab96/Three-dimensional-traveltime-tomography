function u = c_solver2(c_boundary, f, dx, ~, niu)

[N, M] = size(f);
h = dx;
f = f(2:N-1, 2:M-1) / niu;

f(:, 1) = f(:, 1)+c_boundary(2:end-1, 1) / h^2;
f(:,end)=f(:,end)+c_boundary(2:end-1, end) / h^2;
f(1, :) = f(1, :)+c_boundary(1, 2:end-1) / h^2;
f(end,:)=f(end,:)+c_boundary(end, 2:end-1) / h^2;

e=ones(N-2,1);
C = spdiags([-e/h^2, e*(4/h^2 + 1/niu), -e/h^2], [-1, 0, 1], N-2, N-2);
D=-1/h^2*eye(N-2);
e=ones(M-2,1);
A=kron(eye(M-2),C)+kron(spdiags([e e],[-1 1],M-2,M-2),D);

f=f'; u=zeros(M, N);
u(2:M-1,2:N-1)=reshape(A\f(:),N-2,M-2)';
u(:, [1, end]) = c_boundary(:, [1, end]);
u([1, end], :) = c_boundary([1, end], :);
