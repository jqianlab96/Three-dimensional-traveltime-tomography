function beta = lambda_solver(T, T_star, dx, dy, I, J)
% T: traveltime
% T_star: traveltime measured on the boundary
% dx: length of division in the x direction
% dy: length of division in the y direction
% I: number of rows
% J: number of columns

iterFS = 2000;
tolFS = 1e-8;
%% boundary condition
beta = ones(I, J);
for i = 1:I
    beta(i, 1) = (T_star(i, 1) - T(i, 1)) / (-(T(i, 2) - T(i, 1)) / dx);  % left
    beta(i, J) = (T_star(i, J) - T(i, J)) / ((T(i, J) - T(i, J - 1)) / dx);   % right
end
for j = 1:J
    beta(1, j) = (T_star(1, j) - T(1, j)) / (-(T(2, j) - T(1, j)) / dy); % top
    beta(I, j) = (T_star(I, j) - T(I, j)) / ((T(I, j) - T(I - 1, j)) / dy); % bottom
end

%% fast sweeping
T = -T.^2; % change
[Tx, Ty] = gradient(T, dx, dy);
interOrder = {
    [2, 1, I-1, 2, 1, J-1],...
    [I-1, -1, 2, 2, 1, J-1],...
    [I-1, -1, 2, J-1, -1, 2],...
    [2, 1, I-1, J-1, -1, 2]
};

inter_erro = zeros(iterFS, 1);
for k = 1: iterFS
    
    beta_temp = beta;
    order = interOrder{cast(mod(k-1, 4), "uint8") + 1};
    for i = order(1): order(2): order(3)
        for j = order(4): order(5): order(6)

            if Tx(i, j) >= 0 && Ty(i, j) >= 0
                beta(i, j) = (Tx(i, j)*beta(i, j-1) + Ty(i, j)*beta(i-1, j)) / (Tx(i, j) + Ty(i, j) + eps);
            end
            if Tx(i, j) >= 0 && Ty(i, j) < 0
                beta(i, j) = (Tx(i, j)*beta(i, j-1) - Ty(i, j)*beta(i+1, j)) / (Tx(i, j) - Ty(i, j) + eps);
            end
            if Tx(i, j) < 0 && Ty(i, j) >= 0
                beta(i, j) = (-Tx(i, j)*beta(i, j+1) + Ty(i, j)*beta(i-1, j)) / (-Tx(i, j) + Ty(i, j) + eps);
            end
            if Tx(i, j) < 0 && Ty(i, j) < 0
                beta(i, j) = (-Tx(i, j)*beta(i, j+1) - Ty(i, j)*beta(i+1, j)) / (-Tx(i, j) - Ty(i, j) + eps);
            end
            
        end
    end
    
    inter_erro(k) = norm(beta - beta_temp)*dx*dx;
    if inter_erro(k) < tolFS
        break;
    end

end
end