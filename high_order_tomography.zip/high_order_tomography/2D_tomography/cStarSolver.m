function cstar = cStarSolver(T, T_star, dx, I, J, c)

    % beta = lambda_solver(T, T_star, dx, dx, I, J);
    beta = highOrderLambdaSolver(T, T_star, c, dx, dx);
    cstar = -beta ./ c.^3;
    niu = 1;
    cstar = c_solver2(zeros(I, J), cstar, dx, dx, niu);
 
end
