function beta = highOrderLambdaSolver(T, T_star, c, dx, dy)

interFS = 2000;
tolFS = 1e-8;
[I, J] = size(T);
h = dx;
schemeTol = 4;

%% boundary condition and initialization
beta_1st = lambda_solver(T, T_star, dx, dy, I, J);
beta = AdjontState_BoundaryTreatment(beta_1st, T, T_star, c, dx, dy);
% beta = (T_star-T).*T;
% beta(4:end-3, 4:end-3) = beta_1st(4:end-3, 4:end-3);

%% alphax, alphay
T = -T.^2; % change
[Tx, Ty] = weno_gradient(T, dx, dy);
ratio = 1;
alphax = max(max( abs(Tx) ))*ratio;
alphay = max(max( abs(Ty) ))*ratio;

%% fast sweeping
[betax, betay] = gradient(beta, dx, dy);
interOrder = {
    [3, 1, I-2, 3, 1, J-2],...
    [I-2, -1, 3, 3, 1, J-2],...
    [I-2, -1, 3, J-2, -1, 3],...
    [3, 1, I-2, J-2, -1, 3]
};

inter_erro = zeros(interFS, 1);
for k = 1: interFS

    beta_temp = beta;
    order = interOrder{cast(mod(k-1, 4), "uint8") + 1};
    for i = order(1): order(2): order(3)
        for j = order(4): order(5): order(6)

            % upwind
            if abs(betax(i, j))>schemeTol || abs(betay(i, j))>schemeTol

                if Tx(i, j) >= 0 && Ty(i, j) >= 0
                    beta(i, j) = (Tx(i, j)*beta(i, j-1) + Ty(i, j)*beta(i-1, j)) / (Tx(i, j) + Ty(i, j) + eps);
                end
                if Tx(i, j) >= 0 && Ty(i, j) < 0
                    beta(i, j) = (Tx(i, j)*beta(i, j-1) - Ty(i, j)*beta(i+1, j)) / (Tx(i, j) - Ty(i, j) + eps);
                end
                if Tx(i, j) < 0 && Ty(i, j) >= 0
                    beta(i, j) = (-Tx(i, j)*beta(i, j+1) + Ty(i, j)*beta(i-1, j)) / (-Tx(i, j) + Ty(i, j) + eps);
                end
                if Tx(i, j) < 0 && Ty(i, j) < 0
                    beta(i, j) = (-Tx(i, j)*beta(i, j+1) - Ty(i, j)*beta(i+1, j)) / (-Tx(i, j) - Ty(i, j) + eps);
                end

            % Lax-WENO   
            else
                [betay_minus, betay_plus] = WENO_3(beta(i-2, j), beta(i-1, j), beta(i, j), beta(i+1, j), beta(i+2, j), h);
                [betax_minus, betax_plus] = WENO_3(beta(i, j-2), beta(i, j-1), beta(i, j), beta(i, j+1), beta(i, j+2), h); 
        
                beta(i, j) = (h/(alphax + alphay)) * ( - (betax_minus+betax_plus)*Tx(i, j) / 2 - (betay_minus+betay_plus)...
                    *Ty(i, j) / 2 + alphax*(betax_plus-betax_minus)/2 + alphay*(betay_plus-betay_minus)/2) + beta(i, j);
            end
                                
        end
    end
    
    inter_erro(k) = norm(beta-beta_temp)*dx*dy;
    if inter_erro(k) < tolFS
        break;
    end
end