function [u_minus, u_plus] = WENO_3(um2, um1, u, up1, up2, h)

vareps = 1e-6;

r_minus = (vareps+(u - 2*um1 + um2)^2) / (vareps+(up1 - 2*u + um1)^2);
r_plus = (vareps+(up2 - 2*up1 + u)^2) / (vareps+(up1 - 2*u + um1)^2);

w_minus = 1/(1+2*r_minus^2);
w_plus = 1/(1+2*r_plus^2);

u_minus = (1-w_minus)*(up1 - um1)/(2*h) + w_minus*(3*u - 4*um1 + um2)/(2*h);
u_plus = (1-w_plus)*(up1 - um1)/(2*h) + w_plus*(- up2 + 4*up1 -3*u)/(2*h);
