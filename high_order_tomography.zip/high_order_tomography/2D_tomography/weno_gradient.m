function [fx, fy] = weno_gradient(f, dx, dy)

[I, J] = size(f);
[fx, fy] = gradient(f, dx, dy);

for i = 4:I-3
    for j = 4:J-3
        
        [fy_minus, fy_plus] = WENO_5(f(i-3, j), f(i-2, j), f(i-1, j), f(i, j), f(i+1, j), f(i+2, j), f(i+3, j), dy);
        [fx_minus, fx_plus] = WENO_5(f(i, j-3), f(i, j-2), f(i, j-1), f(i, j), f(i, j+1), f(i, j+2), f(i, j+3), dx);
        fx(i, j) = (fx_minus+fx_plus)/2;
        fy(i, j) = (fy_minus+fy_plus)/2;
        
    end
end