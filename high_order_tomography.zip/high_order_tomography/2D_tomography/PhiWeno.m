function Phi = PhiWeno(a, b, c, d)

vareps = 1e-6;

IS0 = 13*(a-b)^2 + 3*(a-3*b)^2;
IS1 = 13*(b-c)^2 + 3*(b+c)^2;
IS2 = 13*(c-d)^2 + 3*(3*c-d)^2;

alpha_0 = 1 / (vareps + IS0)^2;
alpha_1 = 6 / (vareps + IS1)^2;
alpha_2 = 3 / (vareps + IS2)^2;

omega_0 = alpha_0 / (alpha_0 + alpha_1 + alpha_2);
omega_2 = alpha_2 / (alpha_0 + alpha_1 + alpha_2);

Phi = omega_0*(a-2*b+c)/3 + (omega_2-1/2)*(b-2*c+d)/6;