% 5rd order
function T= highOrderEikonalSolver_ext(c, fixed_pt_list, dx, dy, X, Y)

interFS = 2000;
tolFS = 1e-9;
radius = 4;
c_o = c;
X_o = X; Y_o = Y;
[I_o, J_o] = size(c_o);
h = dx;

%% extension
N_extend = 10;
len_extend = 2*h*N_extend;
[X, Y] = meshgrid(linspace(X_o(1, 1)-len_extend, X_o(1, end)+len_extend, J_o+2*N_extend), linspace(Y_o(1, 1)-len_extend, Y_o(end, 1)+len_extend, I_o+2*N_extend));
c = [zeros(N_extend, J_o+2*N_extend); zeros(I_o, N_extend), c_o, zeros(I_o, N_extend); zeros(N_extend, J_o+2*N_extend)];
for ii = N_extend:-1:1
    c(ii,:)=2*c(ii+1, :)-c(ii+2, :);
end
for ii = N_extend-1:-1:0
    c(end-ii,:)=2*c(end-ii-1,:)-c(end-ii-2,:);
end
for ii = N_extend:-1:1
    c(:,ii)=2*c(:,ii+1)-c(:,ii+2);
end
for ii= N_extend-1:-1:0
    c(:,end-ii)=2*c(:,end-ii-1)-c(:,end-ii-2);
end
% len_extend = 2*h*N_extend;
% [X, Y] = meshgrid(linspace(X_o(1, 1)-len_extend, X_o(1, end)+len_extend, J_o+2*N_extend), linspace(Y_o(1, 1)-len_extend, Y_o(end, 1)-len_extend, I_o+2*N_extend));
% c = interp2(X_o, Y_o, c_o, X, Y, 'nearest');
[I, J] = size(c);
fixed_pt_list_o = fixed_pt_list;
fixed_pt_list(1, [2, 3]) = fixed_pt_list_o(1, [2, 3]) + N_extend;

%% initialization of T
fixed_pt_coor = [(fixed_pt_list_o(1, 2)-1)*dx+X_o(1, 1), (fixed_pt_list_o(1, 3)-1)*dy+Y_o(1, 1)];
x0 = fixed_pt_coor(1,1);  y0 = fixed_pt_coor(1,2);
xn = fixed_pt_list(1, 3); yn = fixed_pt_list(1, 2);

S = (1./c ).^2;
[Sx, Sy]  = weno_gradient(S, dx, dy);
[Sxx, Sxy] = weno_gradient(Sx, dx, dy);
[Syx, Syy] = weno_gradient(Sy, dx, dy);
[Sxxx, Sxxy] = weno_gradient(Sxx, dx, dy);
[Syyx, Syyy] = weno_gradient(Syy, dx, dy);
S0 = S(xn, yn);
S1 = Sx(xn, yn).*(X - x0) + Sy(xn, yn).*(Y - y0);
S2 = 0.5*( (X- x0).^2.*Sxx(xn, yn) + (Y-y0).^2.*Syy(xn, yn) + (X- x0).*(Y-y0).*Syx(xn, yn) + (X-x0).*(Y-y0).*Sxy(xn, yn));
S3 = ((X-x0).^3 .* Sxxx(xn, yn) + 3*(X-x0).*(Y-y0).^2 .* Syyx(xn, yn) + 3*(X-x0).^2.*(Y-y0) .* Sxxy(xn, yn) + (Y-y0).^3 .* Syyy(xn, yn))/6;

[S1x, S1y] = weno_gradient(S1, dx, dy);
[S2x, S2y] = weno_gradient(S2, dx, dy);
r_squre = (X-x0).^2 + (Y-y0).^2;
T2 = S0 * r_squre;
T3 = 0.5*S1.*r_squre;
T4 = ( 16*S0.*S2 - r_squre .* (S1x.^2+S1y.^2)) .* r_squre / (48*S0);
T5 = (r_squre).^2.*(-2*S0*(S1x.*S2x + S1y.*S2y) + S1.*(S1x.^2 + S1y.^2)) / (96*S0^2) + r_squre.*S3/4;

T_taylor = T2 + T3 + T4 + T5;
T_taylor(xn, yn) = 0;
T = TravelTime_solver(c, fixed_pt_list, dx, dy, I, J); 
T(xn-radius:xn+radius, yn-radius:yn+radius) = sqrt(T_taylor(xn-radius:xn+radius, yn-radius:yn+radius));

%% initialization of tau_t
tau_t = sqrt(T2);
tau_t(xn, yn) = 0;
dx_tau_t = sqrt(S0)*(X-x0)./sqrt(r_squre); dy_tau_t = sqrt(S0)*(Y-y0)./sqrt(r_squre);

%% initialization of tau_b
tau_b = T ./ tau_t;
tau_b(xn, yn) = 1;

%% fast sweeping
p0=sqrt(S0)*(X-x0)./sqrt((X-x0).^2+(Y-y0).^2);
q0=sqrt(S0)*(Y-y0)./sqrt((X-x0).^2+(Y-y0).^2);

tau_b = [zeros(3, J+6); zeros(I, 3), tau_b, zeros(I, 3); zeros(3, J+6)];
tau_t = [zeros(3, J+6); zeros(I, 3), tau_t, zeros(I, 3); zeros(3, J+6)];
T = [zeros(3, J+6); zeros(I, 3), T, zeros(I, 3); zeros(3, J+6)];
c = [zeros(3, J+6); zeros(I, 3), c, zeros(I, 3); zeros(3, J+6)];
dx_tau_t = [zeros(3, J+6); zeros(I, 3), dx_tau_t, zeros(I, 3); zeros(3, J+6)];
dy_tau_t = [zeros(3, J+6); zeros(I, 3), dy_tau_t, zeros(I, 3); zeros(3, J+6)];

interOrder = { [4, 1, I+3, 4, 1, J+3],...
    [I+3, -1, 4, 4, 1, J+3],...
    [I+3, -1, 4, J+3, -1, 4],...
    [4, 1, I+3, J+3, -1, 4]
};
inter_erro = zeros(interFS, 1);
for k = 1: interFS
    
    T_temp = T;
    order = interOrder{cast(mod(k-1, 4), "uint8") + 1};

    for ii = 3:-1:1
        tau_b(ii,:)=tau_b(ii+1, :);
    end
    for ii = 2:-1:0
        tau_b(end-ii,:)=tau_b(end-ii-1,:);
    end
    for ii = 3:-1:1
        tau_b(:,ii)=tau_b(:,ii+1);
    end
    for ii= 2:-1:0
        tau_b(:,end-ii)=tau_b(:,end-ii-1);
    end
    
    % for ii = 3:-1:1
    %     tau_b(ii,:)=2*tau_b(ii+1, :)-tau_b(ii+2, :);
    % end
    % for ii = 2:-1:0
    %     tau_b(end-ii,:)=2*tau_b(end-ii-1,:)-tau_b(end-ii-2,:);
    % end
    % for ii = 3:-1:1
    %     tau_b(:,ii)=2*tau_b(:,ii+1)-tau_b(:,ii+2);
    % end
    % for ii= 2:-1:0
    %     tau_b(:,end-ii)=2*tau_b(:,end-ii-1)-tau_b(:,end-ii-2);
    % end

%     for ii = 3:-1:1
%         tau_b(ii,:)=6*tau_b(ii+1,:)-15*tau_b(ii+2,:)+20*tau_b(ii+3,:)-15*tau_b(ii+4,:)+6*tau_b(ii+5,:)-tau_b(ii+6,:);
%     end
%     for ii = 2:-1:0
%         tau_b(end-ii,:)=6*tau_b(end-ii-1,:)-15*tau_b(end-ii-2,:)+20*tau_b(end-ii-3,:)-15*tau_b(end-ii-4,:)+6*tau_b(end-ii-5,:)-tau_b(end-ii-6,:);
%     end
%     for ii = 3:-1:1
%         tau_b(:,ii)=6*tau_b(:,ii+1)-15*tau_b(:,ii+2)+20*tau_b(:,ii+3)-15*tau_b(:,ii+4)+6*tau_b(:,ii+5)-tau_b(:,ii+6);
%     end
%     for ii= 2:-1:0
%         tau_b(:,end-ii)=6*tau_b(:,end-ii-1)-15*tau_b(:,end-ii-2)+20*tau_b(:,end-ii-3)-15*tau_b(:,end-ii-4)+6*tau_b(:,end-ii-5)-tau_b(:,end-ii-6);
%     end
    
    
    for i = order(1): order(2): order(3)
        for j = order(4): order(5): order(6)        
            
            num = 1.2;
            alphax = 1e-6 + num*(abs(tau_t(i, j)) + h*(abs(p0(i-3,j-3)+abs(q0(i-3,j-3)))));
            alphay = 1e-6 + num*(abs(tau_t(i, j)) + h*(abs(p0(i-3,j-3)+abs(q0(i-3,j-3)))));
            
            if abs(i-3 - xn)>radius || abs(j-3 - yn)>radius

                [tau_by_minus, tau_by_plus] = WENO_5(tau_b(i-3, j), tau_b(i-2, j), tau_b(i-1, j), tau_b(i, j), tau_b(i+1, j), tau_b(i+2, j), tau_b(i+3, j), h);
                [tau_bx_minus, tau_bx_plus] = WENO_5(tau_b(i, j-3), tau_b(i, j-2), tau_b(i, j-1), tau_b(i, j), tau_b(i, j+1), tau_b(i, j+2), tau_b(i, j+3), h);
               
                tau_b(i, j) = (h/(alphax + alphay)) * ( 1/c(i, j) - sqrt( ( tau_t(i, j)*(tau_bx_minus+tau_bx_plus)/2 + tau_b(i, j)*dx_tau_t(i, j))^2 + ( tau_t(i, j)*(tau_by_minus+...
                        tau_by_plus)/2 + tau_b(i, j)*dy_tau_t(i, j))^2) + alphax*(tau_bx_plus-tau_bx_minus)/2 + alphay*(tau_by_plus-tau_by_minus)/2) + tau_b(i, j);

            end
              
        end
    end
    
    T = tau_b .* tau_t;
    inter_erro(k) = max(max(abs(T(7:end-6, 7:end-6) - T_temp(7:end-6, 7:end-6))));
    if inter_erro(k) < tolFS
        break;
    end
end
T = T(4:end-3, 4:end-3);
T = T(N_extend+1:end-N_extend, N_extend+1:end-N_extend);