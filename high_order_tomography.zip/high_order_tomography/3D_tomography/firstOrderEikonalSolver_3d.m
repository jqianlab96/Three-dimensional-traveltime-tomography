% 1st order
function T = firstOrderEikonalSolver_3d(c, fixed_pt_list, h)

[L, M, N] = size(c);
T = ones(L, M, N)*999;
for idx = 1:size(fixed_pt_list, 1)
    val = fixed_pt_list(idx, 1);
    j = fixed_pt_list(idx, 2); 
    i = fixed_pt_list(idx, 3);
    k = fixed_pt_list(idx, 4);
    T(i, j, k) = val;
end

interOrder = {[1, 1, L, 1, 1, M, 1, 1, N],...
    [1, 1, L, M, -1, 1, 1, 1, N],...
    [L, -1, 1, M, -1, 1, 1, 1, N],...
    [L, -1, 1, 1, 1, M, 1, 1, N],...
    [1, 1, L, 1, 1, M, N, -1, 1],...
    [1, 1, L, M, -1, 1, N, -1, 1],...
    [L, -1, 1, M, -1, 1, N, -1, 1],...
    [L, -1, 1, 1, 1, M, N, -1, 1]};

interFS = 5000;
tolFS = 1e-9;
iter_error = zeros(interFS, 1);
for times = 1: interFS
    
    T_temp = T;
    order = interOrder{cast(mod(times-1, 8), "uint8") + 1};
    for i = order(1): order(2): order(3)
        for j = order(4): order(5): order(6)    
            for k = order(7): order(8): order(9)     
            
            if i ~= 1 && i ~= L
                a1 = min(T(i-1, j, k), T(i+1, j, k));
            else
                if i == 1
                    a1 = 2*T(i+1, j, k) - T(i+2, j, k);
                else
                    a1 = 2*T(i-1, j, k) - T(i-2, j, k);
                end
            end
            
            if j ~= 1 && j ~= M
                a2 = min(T(i, j-1, k), T(i, j+1, k));
            else
                if j == 1
                    a2 = 2*T(i, j+1, k) - T(i, j+2, k);
                else
                    a2 = 2*T(i, j-1, k) - T(i, j-2, k);
                end
            end

            if k ~= 1 && k ~= N
                a3 = min(T(i, j, k-1), T(i, j, k+1));
            else
                if k == 1
                    a3 = 2*T(i, j, k+1) - T(i, j, k+2);
                else
                    a3 = 2*T(i, j, k-1) - T(i, j, k-2);
                end
            end
                
            a = sort([a1, a2, a3]);

            if a(1)+h/c(i, j, k) <= a(2)
                Tijk = a(1)+h/c(i, j, k);
            else
                Tijk_temp = ( a(1)+a(2)+sqrt(2*h^2/c(i, j, k)^2 - (a(1)-a(2))^2) )/2;
                if Tijk_temp <= a(3)
                    Tijk = Tijk_temp;
                else
                    Tijk = ( a(1)+a(2)+a(3) + sqrt((a(1)+a(2)+a(3))^2 - 3*(a(1)^2+a(2)^2+a(3)^2-h^2/c(i, j, k)^2)) )/3;
                end
            end
            T(i, j, k) = min(T(i, j, k), Tijk);
            
            end
        end
    end

    for idx = 1:size(fixed_pt_list, 1)
        val = fixed_pt_list(idx, 1);
        j = fixed_pt_list(idx, 2); 
        i = fixed_pt_list(idx, 3);
        k = fixed_pt_list(idx, 4);
        T(i, j, k) = val;
    end
    
    iter_error(times) = max(abs(T(:)-T_temp(:)));
    if iter_error(times) < tolFS
        break;
    end

end