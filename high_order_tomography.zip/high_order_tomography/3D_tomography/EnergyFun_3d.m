% EnergyFun
function E = EnergyFun_3d(T, T_star, h)

[I, J, K] = size(T);

E1 = sum(sum((T(1, :, :) - T_star(1, :, :)).^2)) * h*h;
E2 = sum(sum((T(I, :, :) - T_star(I, :, :)).^2)) * h*h;
E3 = sum(sum((T(2:I-1, 1, :) - T_star(2:I-1, 1, :)).^2)) * h*h;
E4 = sum(sum((T(2:I-1, J, :) - T_star(2:I-1, J, :)).^2)) * h*h;
E5 = sum(sum((T(2:I-1, 2:J-1, 1) - T_star(2:I-1, 2:J-1, 1)).^2)) * h*h;
E6 = sum(sum((T(2:I-1, 2:J-1, K) - T_star(2:I-1, 2:J-1, K)).^2)) * h*h;
E = (E1+E2+E3+E4+E5+E6)*0.5;

end