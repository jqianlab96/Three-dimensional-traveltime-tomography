% 5rd order
function T= highOrderEikonalSolver_3d(c, fixed_pt_list, h, X, Y, Z)

interFS = 2000;
tolFS = 1e-9;
radius = 4;
[I, J, K] = size(c);

%% initialization of T
fixed_pt_coor = [(fixed_pt_list(1, 2)-1)*h+X(1, 1, 1), (fixed_pt_list(1, 3)-1)*h+Y(1, 1, 1), (fixed_pt_list(1, 4)-1)*h+Z(1, 1, 1)];
x0 = fixed_pt_coor(1,1);  y0 = fixed_pt_coor(1,2); z0 = fixed_pt_coor(1,3);
xn = fixed_pt_list(1, 3); yn = fixed_pt_list(1, 2); zn = fixed_pt_list(1, 4);
    
S = (1./c ).^2;
[Sx, Sy, Sz]  =weno_gradient_3d(S, h, h, h);
[Sxx, Sxy, Sxz] = weno_gradient_3d(Sx, h, h, h);
[Syx, Syy, Syz] = weno_gradient_3d(Sy, h, h, h);
[Szx, Szy, Szz] = weno_gradient_3d(Sz, h, h, h);
[Sxxx, Sxxy, Sxxz] = weno_gradient_3d(Sxx, h, h, h);
[Syyx, Syyy, Syyz] = weno_gradient_3d(Syy, h, h, h);
[Szzx, Szzy, Szzz] = weno_gradient_3d(Szz, h, h, h);
[~, ~, Sxyz] = weno_gradient_3d(Sxy, h, h, h);

S0 = S(xn, yn, zn);
S1 = Sx(xn, yn, zn).*(X - x0) + Sy(xn, yn, zn).*(Y - y0) + Sz(xn, yn, zn).*(Z-z0);
S2 = 0.5*( (X- x0).^2.*Sxx(xn, yn, zn) + (Y-y0).^2.*Syy(xn, yn, zn) + (Z-z0).^2.*Szz(xn, yn, zn) +...
    2*(X- x0).*(Y-y0).*Syx(xn, yn, zn) + 2*(X- x0).*(Z-y0).*Szx(xn, yn, zn) + 2*(Z- z0).*(Y-y0).*Syz(xn, yn, zn) +...
    2*(X- x0).*(Y-y0).*Sxy(xn, yn, zn) + 2*(X- x0).*(Z-y0).*Sxz(xn, yn, zn) + 2*(Z- z0).*(Y-y0).*Szy(xn, yn, zn));
S3 = ((X-x0).^3 .* Sxxx(xn, yn, zn) + (Y-y0).^3 .* Syyy(xn, yn, zn) + (Z-z0).^3 .* Szzz(xn, yn, zn) + ...
     3*(X-x0).^2.*(Y-y0) .* Sxxy(xn, yn, zn) + 3*(X-x0).^2.*(Z-z0) .* Sxxz(xn, yn, zn) +...
     3*(Y-y0).^2.*(X-x0) .* Syyx(xn, yn, zn) + 3*(Y-y0).^2.*(Z-z0) .* Syyz(xn, yn, zn) +...
     3*(Z-z0).^2.*(X-x0) .* Szzx(xn, yn, zn) + 3*(Z-z0).^2.*(Y-y0) .* Szzy(xn, yn, zn) +...
     6*(X-x0).*(Y-y0).*(Z-z0) .* Sxyz(xn, yn, zn) )/6;

[S1x, S1y, S1z] = weno_gradient_3d(S1, h, h, h);
[S2x, S2y, S2z] = weno_gradient_3d(S2, h, h, h);
r_squre = (X-x0).^2 + (Y-y0).^2 + (Z-z0).^2;
T2 = S0 * r_squre;
T3 = 0.5*S1.*r_squre;
T4 = ( 16*S0.*S2 - r_squre .* (S1x.^2+S1y.^2+S1z.^2)) .* r_squre / (48*S0);
T5 = (r_squre).^2.*(-2*S0*(S1x.*S2x + S1y.*S2y + S1z.*S2z) + S1.*(S1x.^2 + S1y.^2 + S1z.^2)) / (96*S0^2) + r_squre.*S3/4;

T_taylor = T2 + T3 + T4 + T5;
T_taylor(xn, yn, zn) = 0;
T =  firstOrderEikonalSolver_3d(c, fixed_pt_list, h);
T(xn-radius:xn+radius, yn-radius:yn+radius, zn-radius:zn+radius) = sqrt(T_taylor(xn-radius:xn+radius, yn-radius:yn+radius, zn-radius:zn+radius));

%% initialization of tau_t
tau_t = sqrt(T2);
tau_t(xn, yn, zn) = 0;
dx_tau_t = sqrt(S0)*(X-x0)./sqrt(r_squre); dy_tau_t = sqrt(S0)*(Y-y0)./sqrt(r_squre); dz_tau_t = sqrt(S0)*(Z-z0)./sqrt(r_squre);

%% initialization of tau_b
tau_b = T ./ tau_t;
tau_b(xn, yn, zn) = 1;

%% fast sweeping
p0=sqrt(S0)*(X-x0)./sqrt((X-x0).^2+(Y-y0).^2+(Z-z0).^2);
q0=sqrt(S0)*(Y-y0)./sqrt((X-x0).^2+(Y-y0).^2+(Z-z0).^2);
r0=sqrt(S0)*(Z-z0)./sqrt((X-x0).^2+(Y-y0).^2+(Z-z0).^2);

tau_b_temp = zeros(I+6, J+6, K+6); tau_b_temp(4:end-3, 4:end-3, 4:end-3) = tau_b;tau_b = tau_b_temp;
tau_t_temp = zeros(I+6, J+6, K+6);  tau_t_temp(4:end-3, 4:end-3, 4:end-3) = tau_t;  tau_t = tau_t_temp;
T_temp = zeros(I+6, J+6, K+6);  T_temp(4:end-3, 4:end-3, 4:end-3) = T;  T = T_temp;
c_temp = zeros(I+6, J+6, K+6);  c_temp(4:end-3, 4:end-3, 4:end-3) = c;  c = c_temp;
dx_tau_t_temp = zeros(I+6, J+6, K+6);  dx_tau_t_temp(4:end-3, 4:end-3, 4:end-3) = dx_tau_t;  dx_tau_t = dx_tau_t_temp;
dy_tau_t_temp = zeros(I+6, J+6, K+6);  dy_tau_t_temp(4:end-3, 4:end-3, 4:end-3) = dy_tau_t;  dy_tau_t = dy_tau_t_temp;
dz_tau_t_temp = zeros(I+6, J+6, K+6);  dz_tau_t_temp(4:end-3, 4:end-3, 4:end-3) = dz_tau_t;  dz_tau_t = dz_tau_t_temp;

interOrder = {[4, 1, I+3, 4, 1, J+3, 4, 1, K+3],...
    [4, 1, I+3, J+3, -1, 4, 4, 1, K+3],...
    [I+3, -1, 4, J+3, -1, 4, 4, 1, K+3],...
    [I+3, -1, 4, 4, 1, J+3, 4, 1, K+3],...
    [4, 1, I+3, 4, 1, J+3, K+3, -1, 4],...
    [4, 1, I+3, J+3, -1, 4, K+3, -1, 4],...
    [I+3, -1, 4, J+3, -1, 4, K+3, -1, 4],...
    [I+3, -1, 4, 4, 1, J+3, K+3, -1, 4]};

inter_error = zeros(interFS, 1);
for times = 1: interFS
    
    T_temp = T;
    order = interOrder{cast(mod(times-1, 8), "uint8") + 1};

    for ii = 3:-1:1
        tau_b(ii, :, :)=tau_b(ii+1, :, :);
    end
    for ii = 2:-1:0
        tau_b(end-ii, :, :)=tau_b(end-ii-1, :, :);
    end
    for ii = 3:-1:1
        tau_b(:, ii, :)=tau_b(:, ii+1, :);
    end
    for ii= 2:-1:0
        tau_b(:, end-ii, :)=tau_b(:, end-ii-1, :);
    end
    for ii = 3:-1:1
        tau_b(:, :, ii)=tau_b(:, :, ii+1);
    end
    for ii= 2:-1:0
        tau_b(:, :, end-ii)=tau_b(:, :, end-ii-1);
    end
    
    
    for i = order(1): order(2): order(3)
        for j = order(4): order(5): order(6)   
            for k = order(7): order(8): order(9)
            
                num = 1;
                alphax = 1e-6 + num*(abs(tau_t(i, j, k)) + h*(abs(p0(i-3,j-3, k-3)+abs(q0(i-3,j-3, k-3))+abs(r0(i-3,j-3, k-3)))));
                alphay = 1e-6 + num*(abs(tau_t(i, j, k)) + h*(abs(p0(i-3,j-3, k-3)+abs(q0(i-3,j-3, k-3))+abs(r0(i-3,j-3, k-3)))));
                alphaz = 1e-6 + num*(abs(tau_t(i, j, k)) + h*(abs(p0(i-3,j-3, k-3)+abs(q0(i-3,j-3, k-3))+abs(r0(i-3,j-3, k-3)))));
            
                if abs(i-3 - xn)>radius || abs(j-3 - yn)>radius || abs(k-3 - zn)>radius
    
                    [tau_by_minus, tau_by_plus] = WENO_5(tau_b(i-3, j, k), tau_b(i-2, j, k), tau_b(i-1, j, k), tau_b(i, j, k), tau_b(i+1, j, k), tau_b(i+2, j, k), tau_b(i+3, j, k), h);
                    [tau_bx_minus, tau_bx_plus] = WENO_5(tau_b(i, j-3, k), tau_b(i, j-2, k), tau_b(i, j-1, k), tau_b(i, j, k), tau_b(i, j+1, k), tau_b(i, j+2, k), tau_b(i, j+3, k), h);
                    [tau_bz_minus, tau_bz_plus] = WENO_5(tau_b(i, j, k-3), tau_b(i, j, k-2), tau_b(i, j, k-1), tau_b(i, j, k), tau_b(i, j, k+1), tau_b(i, j, k+2), tau_b(i, j, k+3), h);
                   
                    tau_b(i, j, k) = (h/(alphax + alphay + alphaz)) * ( 1/c(i, j, k) - sqrt( ( tau_t(i, j, k)*(tau_bx_minus+tau_bx_plus)/2 + tau_b(i, j, k)*dx_tau_t(i, j, k))^2 + ...
                        ( tau_t(i, j, k)*(tau_by_minus+ tau_by_plus)/2 + tau_b(i, j, k)*dy_tau_t(i, j, k))^2 + ...
                        ( tau_t(i, j, k)*(tau_bz_minus+ tau_bz_plus)/2 + tau_b(i, j, k)*dz_tau_t(i, j, k))^2 ) + ...
                        alphax*(tau_bx_plus-tau_bx_minus)/2 + alphay*(tau_by_plus-tau_by_minus)/2 + alphaz*(tau_bz_plus-tau_bz_minus)/2) + tau_b(i, j, k);
    
                end

            end
        end
    end
    
    T = tau_b .* tau_t;
    inter_error(times) = max(max(max(abs(T(7:end-6, 7:end-6, 7:end-6) - T_temp(7:end-6, 7:end-6, 7:end-6)))));
    if inter_error(times) < tolFS
        break;
    end
end
T = T(4:end-3, 4:end-3, 4:end-3);