function lambda = AdjontState_BoundaryTreatment_3d(lambda, T, T_star, h)

lambda_t = lambda;
[I, J, K] = size(lambda);

T_x1 = (-11*T(:, 1, :)+18*T(:, 2, :)-9*T(:, 3, :)+2*T(:, 4, :)) / (6*h);
T_x2 = (-2*T(:, J-3, :)+9*T(:, J-2, :)-18*T(:, J-1, :)+11*T(:, J, :)) / (6*h);
lambda(:, 1, :) = (T_star(:, 1, :) - T(:, 1, :)) ./ (-T_x1);  % left
lambda(:, J, :) = (T_star(:, J, :) - T(:, J, :)) ./ (T_x2);   % right

T_y1 = (-11*T(1, :, :)+18*T(2, :, :)-9*T(3, :, :)+2*T(4, :, :)) / (6*h);
T_y2 = (-2*T(I-3, :, :)+9*T(I-2, :, :)-18*T(I-1, :, :)+11*T(I, :, :)) / (6*h);
lambda(1, :, :) = (T_star(1, :, :) - T(1, :, :)) ./ (-T_y1); % top
lambda(I, :, :) = (T_star(I, :, :) - T(I, :, :)) ./ (T_y2); % bottom

T_z1 = (-11*T(:, :, 1)+18*T(:, :, 2)-9*T(:, :, 3)+2*T(:, :, 4)) / (6*h);
T_z2 = (-2*T(:, :, I-3)+9*T(:, :, I-2)-18*T(:, :, I-1)+11*T(:, :, I)) / (6*h);
lambda(:, :, 1) = (T_star(:, :, 1) - T(:, :, 1)) ./ (-T_z1); % top
lambda(:, :, K) = (T_star(:, :, K) - T(:, :, K)) ./ (T_z2); % bottom


N_t = 5;
[Tx, Ty, Tz] = weno_gradient_3d(T, h, h, h);
[lambda_x, lambda_y, lambda_z] = weno_gradient_3d(lambda, h, h, h);

% 1
tspan = (0:h/N_t:h)';
for k = 2:K-1
    y = @(t,y) -( ((lambda_y(:, 2, k)-lambda_y(:, 1, k))/h.*t+lambda_y(:, 1, k)) .* ((Ty(:, 2, k)-Ty(:, 1, k)).*t+Ty(:, 1, k)) + ...
        ((lambda_z(:, 2, k)-lambda_z(:, 1, k))/h.*t+lambda_z(:, 1, k)) .* ((Tz(:, 2, k)-Tz(:, 1, k)).*t+Tz(:, 1, k)) ) ./ ((Tx(:, 2, k)-Tx(:, 1, k)).*t+Tx(:, 1, k));
    [~,lambda_temp] = ode45(y, tspan, lambda(:, 1, k));
    lambda(2:end-1, 2, k) = lambda_temp(end, 2:end-1);
end

% 2
tspan = (0:h/N_t:h)';
for k = 2:K-1
    y = @(t,y) -( ((lambda_x(2, :, k)'-lambda_x(1, :, k)')/h.*t+lambda_x(1, :, k)') .* ((Tx(2, :, k)'-Tx(1, :, k)').*t+Tx(1, :, k)') + ...
         ((lambda_z(2, :, k)'-lambda_z(1, :, k)')/h.*t+lambda_z(1, :, k)') .* ((Tz(2, :, k)'-Tz(1, :, k)').*t+Tz(1, :, k)') ) ./ ((Ty(2, :, k)'-Ty(1, :, k)').*t+Ty(1, :, k)');
    [~,lambda_temp] = ode45(y, tspan, lambda(1, :, k)');
    lambda(2, 2:end-1, k) = lambda_temp(end, 2:end-1)';
end

% 3
tspan = (h:-h/N_t:0)';
for k = 2:K-1
    y = @(t,y) -( ((lambda_y(:, end, k)-lambda_y(:, end-1, k))/h.*t+lambda_y(:, end-1, k)) .* ((Ty(:, end, k)-Ty(:, end-1, k)).*t+Ty(:, end-1, k)) + ...
    ((lambda_z(:, end, k)-lambda_z(:, end-1, k))/h.*t+lambda_z(:, end-1, k)) .* ((Tz(:, end, k)-Tz(:, end-1, k)).*t+Tz(:, end-1, k))) ./ ((Tx(:, end, k)-Tx(:, end-1, k)).*t+Tx(:, end-1, k));
    [~,lambda_temp] = ode45(y, tspan, lambda(:, end, k));
    lambda(2:end-1, end-1, k) = lambda_temp(end, 2:end-1);
end

% 4
tspan = (h:-h/N_t:0)';
for k = 2:K-1
    y = @(t,y) -( ((lambda_x(end, :, k)'-lambda_x(end-1, :, k)')/h.*t+lambda_x(end-1, :, k)') .* ((Tx(end, :, k)'-Tx(end-1, :, k)').*t+Tx(end-1, :, k)') + ...
    ((lambda_z(end, :, k)'-lambda_z(end-1, :, k)')/h.*t+lambda_z(end-1, :, k)') .* ((Tz(end, :, k)'-Tz(end-1, :, k)').*t+Tz(end-1, :, k)') ) ./ ((Ty(end, :, k)'-Ty(end-1, :, k)').*t+Ty(end-1, :, k)');
    [~,lambda_temp] = ode45(y, tspan, lambda(end, :, k)');
    lambda(end-1, 2:end-1, k) = lambda_temp(end, 2:end-1)';
end

% 5
tspan = (0:h/N_t:h)';
for j = 2:J-1
    y = @(t,y) -( (permute(lambda_x(2, j, :)-lambda_x(1, j, :), [3 2 1])/h.*t+permute(lambda_x(1, j, :), [ 3 2 1])) .* (permute(Tx(2, j, :)-Tx(1, j, :), [3 2 1]).*t+permute(Tx(1, j, :), [3 2 1])) + ...
        (permute(lambda_y(2, j, :)-lambda_y(1, j, :), [3 2 1])/h.*t+permute(lambda_y(1, j, :), [3 2 1])) .* (permute(Ty(2, j, :)-Ty(1, j, :), [3 2 1]).*t+permute(Ty(1, j, :), [ 3 2 1])) ) ./ (permute(Tz(2, j, :)-Tz(1, j, :), [3 2 1]).*t+permute(Tz(1, j, :), [ 3 2 1]) + eps);
    [~,lambda_temp] = ode45(y, tspan, permute(lambda(1, j, :), [3 2 1]));
    lambda(2, j, 2:end-1) = lambda_temp(end, 2:end-1);
end

% 6
tspan = (h:-h/N_t:0)';
for j = 2:J-1
    y = @(t,y) -( (permute(lambda_x(end, j, :)-lambda_x(end-1, j, :), [3 2 1])/h.*t+permute(lambda_x(end-1, j, :), [ 3 2 1])) .* (permute(Tx(end, j, :)-Tx(end-1, j, :), [3 2 1]).*t+permute(Tx(end-1, j, :), [3 2 1])) + ...
        (permute(lambda_y(end, j, :)-lambda_y(end-1, j, :), [3 2 1])/h.*t+permute(lambda_y(end-1, j, :), [3 2 1])) .* (permute(Ty(end, j, :)-Ty(end-1, j, :), [3 2 1]).*t+permute(Ty(end-1, j, :), [ 3 2 1])) ) ./ (permute(Tz(end, j, :)-Tz(end-1, j, :), [3 2 1]).*t+permute(Tz(end-1, j, :), [ 3 2 1]) + eps);
    [~,lambda_temp] = ode45(y, tspan, permute(lambda(end, j, :), [3 2 1]));
    lambda(end-1, j, 2:end-1) = lambda_temp(end, 2:end-1);
end

% exceptions
except = 0.005;
lambda(abs(lambda_t-lambda)>except) = lambda_t(abs(lambda_t-lambda)>except);

end