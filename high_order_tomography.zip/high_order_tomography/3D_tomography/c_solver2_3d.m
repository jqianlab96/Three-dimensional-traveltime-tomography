function u = c_solver2_3d(g, f, h, niu)

[L, M, N] = size(f);

u = ones(L ,M ,N);
u(:, :, [1, end]) = g(:, :, [1, end]);
u(:, [1, end], :) = g(:, [1, end], :);
u([1, end], :, :) = g([1, end], :, :);

maxIter = 5000;
tol = 1e-9;
for t = 1:maxIter
    
    u_temp = u;
    for i = 2:L-1
        for j = 2:M-1
            for k = 2:N-1
                u(i, j, k) = (f(i, j, k) + niu/h^2 * (u(i-1, j, k)+u(i+1, j, k)+u(i, j-1, k)+u(i, j+1, k)+u(i, j, k-1)+u(i, j, k+1)) ) / (1+6*niu/h^2);
            end
        end
    end

    if max(abs(u(:) - u_temp(:))) < tol
        % fprintf('Converged after %d iterations\n', t);
        break;
    end

end
