function beta = firstOrderLambdaSolver_3d(T, T_star, h)

iterFS = 2000;
tolFS = 1e-9;
[L, M, N] = size(T);
%% boundary condition
beta = ones(L, M, N);
beta(1, :, :) = (T_star(1, :, :) - T(1, :, :)) ./ (-(T(2, :, :) - T(1, :, :)) / h);
beta(L, :, :) = (T_star(L, :, :) - T(L, :, :)) ./ ((T(L, :, :) - T(L - 1, :, :)) / h);
beta(:, 1, :) = (T_star(:, 1, :) - T(:, 1, :)) ./ (-(T(:, 2, :) - T(:, 1, :)) / h);
beta(:, M, :) = (T_star(:, M, :) - T(:, M, :)) ./ ((T(:, M, :) - T(:, M - 1, :)) / h);
beta(:, :, 1) = (T_star(:, :, 1) - T(:, :, 1)) ./ (-(T(:, :, 2) - T(:, :, 1)) / h);
beta(:, :, N) = (T_star(:, :, N) - T(:, :, N)) ./ ((T(:, :, N) - T(:, :, N-1)) / h);

%% fast sweeping
T = -T.^2; % change
[Tx, Ty, Tz] = gradient(T, h, h, h);
interOrder = {[2, 1, L-1, 2, 1, M-1, 2, 1, N-1],...
    [2, 1, L-1, M-1, -1, 2, 2, 1, N-1],...
    [L-1, -1, 2, M-1, -1, 2, 2, 1, N-1],...
    [L-1, -1, 2, 2, 1, M-1, 2, 1, N-1],...
    [2, 1, L-1, 2, 1, M-1, N-1, -1, 2],...
    [2, 1, L-1, M-1, -1, 2, N-1, -1, 2],...
    [L-1, -1, 2, M-1, -1, 2, N-1, -1, 2],...
    [L-1, -1, 2, 2, 1, M-1, N-1, -1, 2]};

inter_erro = zeros(iterFS, 1);
for times = 1: iterFS
    
    beta_temp = beta;
    order = interOrder{cast(mod(times-1, 8), "uint8") + 1};
    for i = order(1): order(2): order(3)
        for j = order(4): order(5): order(6)
            for k = order(7): order(8): order(9)

                % i,j,k--k,j,i
                % if Tx(i, j, k) >= 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) >= 0
                %     beta(i, j, k) = (Tx(i, j, k)*beta(i, j, k-1) + Ty(i, j, k)*beta(i, j-1, k) + Tz(i, j, k)*beta(i-1, j, k)) / (Tx(i, j, k) + Ty(i, j, k) +Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) >= 0 && Ty(i, j, k) < 0 && Tz(i, j, k) >= 0
                %     beta(i, j, k) = (Tx(i, j, k)*beta(i, j, k-1) - Ty(i, j, k)*beta(i, j+1, k) + Tz(i, j, k)*beta(i-1, j, k)) / (Tx(i, j, k) - Ty(i, j, k) +Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) < 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) >= 0
                %     beta(i, j, k) = (-Tx(i, j, k)*beta(i, j, k+1) + Ty(i, j, k)*beta(i, j-1, k) + Tz(i, j, k)*beta(i-1, j, k)) / (-Tx(i, j, k) + Ty(i, j, k) + Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) < 0 && Ty(i, j, k) < 0 && Tz(i, j, k) >= 0
                %     beta(i, j, k) = (-Tx(i, j, k)*beta(i, j, k+1) - Ty(i, j, k)*beta(i, j+1, k) + Tz(i, j, k)*beta(i-1, j, k)) / (-Tx(i, j, k) - Ty(i, j, k) + Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) >= 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) < 0
                %     beta(i, j, k) = (Tx(i, j, k)*beta(i, j, k-1) + Ty(i, j, k)*beta(i, j-1, k) - Tz(i, j, k)*beta(i+1, j, k)) / (Tx(i, j, k) + Ty(i, j, k) - Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) >= 0 && Ty(i, j, k) < 0 && Tz(i, j, k) < 0
                %     beta(i, j, k) = (Tx(i, j, k)*beta(i, j, k-1) - Ty(i, j, k)*beta(i, j+1, k) - Tz(i, j, k)*beta(i+1, j, k)) / (Tx(i, j, k) - Ty(i, j, k) - Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) < 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) < 0
                %     beta(i, j, k) = (-Tx(i, j, k)*beta(i, j, k+1) + Ty(i, j, k)*beta(i, j-1, k) - Tz(i, j, k)*beta(i+1, j, k)) / (-Tx(i, j, k) + Ty(i, j, k) - Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) < 0 && Ty(i, j, k) < 0 && Tz(i, j, k) < 0
                %     beta(i, j, k) = (-Tx(i, j, k)*beta(i, j, k+1) - Ty(i, j, k)*beta(i, j+1, k) - Tz(i, j, k)*beta(i+1, j, k)) / (-Tx(i, j, k) - Ty(i, j, k) - Tz(i, j, k) + eps);
                % end

                % stay
                % if Tx(i, j, k) >= 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) >= 0
                %     beta(i, j, k) = (Tx(i, j, k)*beta(i-1, j, k) + Ty(i, j, k)*beta(i, j-1, k) + Tz(i, j, k)*beta(i, j, k-1)) / (Tx(i, j, k) + Ty(i, j, k) +Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) >= 0 && Ty(i, j, k) < 0 && Tz(i, j, k) >= 0
                %     beta(i, j, k) = (Tx(i, j, k)*beta(i-1, j, k) - Ty(i, j, k)*beta(i, j+1, k) + Tz(i, j, k)*beta(i, j, k-1)) / (Tx(i, j, k) - Ty(i, j, k) +Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) < 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) >= 0
                %     beta(i, j, k) = (-Tx(i, j, k)*beta(i+1, j, k) + Ty(i, j, k)*beta(i, j-1, k) + Tz(i, j, k)*beta(i, j, k-1)) / (-Tx(i, j, k) + Ty(i, j, k) + Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) < 0 && Ty(i, j, k) < 0 && Tz(i, j, k) >= 0
                %     beta(i, j, k) = (-Tx(i, j, k)*beta(i+1, j, k) - Ty(i, j, k)*beta(i, j+1, k) + Tz(i, j, k)*beta(i, j, k-1)) / (-Tx(i, j, k) - Ty(i, j, k) + Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) >= 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) < 0
                %     beta(i, j, k) = (Tx(i, j, k)*beta(i-1, j, k) + Ty(i, j, k)*beta(i, j-1, k) - Tz(i, j, k)*beta(i, j, k+1)) / (Tx(i, j, k) + Ty(i, j, k) - Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) >= 0 && Ty(i, j, k) < 0 && Tz(i, j, k) < 0
                %     beta(i, j, k) = (Tx(i, j, k)*beta(i-1, j, k) - Ty(i, j, k)*beta(i, j+1, k) - Tz(i, j, k)*beta(i, j, k+1)) / (Tx(i, j, k) - Ty(i, j, k) - Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) < 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) < 0
                %     beta(i, j, k) = (-Tx(i, j, k)*beta(i+1, j, k) + Ty(i, j, k)*beta(i, j-1, k) - Tz(i, j, k)*beta(i, j, k+1)) / (-Tx(i, j, k) + Ty(i, j, k) - Tz(i, j, k) + eps);
                % end
                % if Tx(i, j, k) < 0 && Ty(i, j, k) < 0 && Tz(i, j, k) < 0
                %     beta(i, j, k) = (-Tx(i, j, k)*beta(i+1, j, k) - Ty(i, j, k)*beta(i, j+1, k) - Tz(i, j, k)*beta(i, j, k+1)) / (-Tx(i, j, k) - Ty(i, j, k) - Tz(i, j, k) + eps);
                % end
                
                % i,j,k--j,i,k
                if Tx(i, j, k) >= 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) >= 0
                    beta(i, j, k) = (Tx(i, j, k)*beta(i, j-1, k) + Ty(i, j, k)*beta(i-1, j, k) + Tz(i, j, k)*beta(i, j, k-1)) / (Tx(i, j, k) + Ty(i, j, k) +Tz(i, j, k) + eps);
                end
                if Tx(i, j, k) >= 0 && Ty(i, j, k) < 0 && Tz(i, j, k) >= 0
                    beta(i, j, k) = (Tx(i, j, k)*beta(i, j-1, k) - Ty(i, j, k)*beta(i+1, j, k) + Tz(i, j, k)*beta(i, j, k-1)) / (Tx(i, j, k) - Ty(i, j, k) +Tz(i, j, k) + eps);
                end
                if Tx(i, j, k) < 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) >= 0
                    beta(i, j, k) = (-Tx(i, j, k)*beta(i, j+1, k) + Ty(i, j, k)*beta(i-1, j, k) + Tz(i, j, k)*beta(i, j, k-1)) / (-Tx(i, j, k) + Ty(i, j, k) + Tz(i, j, k) + eps);
                end
                if Tx(i, j, k) < 0 && Ty(i, j, k) < 0 && Tz(i, j, k) >= 0
                    beta(i, j, k) = (-Tx(i, j, k)*beta(i, j+1, k) - Ty(i, j, k)*beta(i+1, j, k) + Tz(i, j, k)*beta(i, j, k-1)) / (-Tx(i, j, k) - Ty(i, j, k) + Tz(i, j, k) + eps);
                end
                if Tx(i, j, k) >= 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) < 0
                    beta(i, j, k) = (Tx(i, j, k)*beta(i, j-1, k) + Ty(i, j, k)*beta(i-1, j, k) - Tz(i, j, k)*beta(i, j, k+1)) / (Tx(i, j, k) + Ty(i, j, k) - Tz(i, j, k) + eps);
                end
                if Tx(i, j, k) >= 0 && Ty(i, j, k) < 0 && Tz(i, j, k) < 0
                    beta(i, j, k) = (Tx(i, j, k)*beta(i, j-1, k) - Ty(i, j, k)*beta(i+1, j, k) - Tz(i, j, k)*beta(i, j, k+1)) / (Tx(i, j, k) - Ty(i, j, k) - Tz(i, j, k) + eps);
                end
                if Tx(i, j, k) < 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) < 0
                    beta(i, j, k) = (-Tx(i, j, k)*beta(i, j+1, k) + Ty(i, j, k)*beta(i-1, j, k) - Tz(i, j, k)*beta(i, j, k+1)) / (-Tx(i, j, k) + Ty(i, j, k) - Tz(i, j, k) + eps);
                end
                if Tx(i, j, k) < 0 && Ty(i, j, k) < 0 && Tz(i, j, k) < 0
                    beta(i, j, k) = (-Tx(i, j, k)*beta(i, j+1, k) - Ty(i, j, k)*beta(i+1, j, k) - Tz(i, j, k)*beta(i, j, k+1)) / (-Tx(i, j, k) - Ty(i, j, k) - Tz(i, j, k) + eps);
                end

            end
        end
    end
    
    inter_erro(times) = max(abs(beta(:) - beta_temp(:)));
    if inter_erro(times) < tolFS
        break;
    end

end
end
