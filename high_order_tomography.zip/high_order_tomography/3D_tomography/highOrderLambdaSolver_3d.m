function beta = highOrderLambdaSolver_3d(T, T_star, h)

interFS = 2000;
tolFS = 1e-9;
[L, M, N] = size(T);
schemeTol = 4;

%% boundary condition and initialization
beta_1st = firstOrderLambdaSolver_3d(T, T_star, h);
beta = AdjontState_BoundaryTreatment_3d(beta_1st, T, T_star, h);

%% alphax, alphay
T = -T.^2; % change
[Tx, Ty, Tz] = weno_gradient_3d(T, h, h, h);
ratio = 1;
alphax = max(max(max( abs(Tx) )))*ratio;
alphay = max(max(max( abs(Ty) )))*ratio;
alphaz = max(max(max( abs(Tz) )))*ratio;

%% fast sweeping
[betax, betay, betaz] = gradient(beta, h, h, h);
interOrder = {[3, 1, L-2, 3, 1, M-2, 3, 1, N-2],...
    [3, 1, L-2, M-2, -1, 3, 3, 1, N-2],...
    [L-2, -1, 3, M-2, -1, 3, 3, 1, N-2],...
    [L-2, -1, 3, 3, 1, M-2, 3, 1, N-2],...
    [3, 1, L-2, 3, 1, M-2, N-2, -1, 3],...
    [3, 1, L-2, M-2, -1, 3, N-2, -1, 3],...
    [L-2, -1, 3, M-2, -1, 3, N-2, -1, 3],...
    [L-2, -1, 3, 3, 1, M-2, N-2, -1, 3]};

inter_error = zeros(interFS, 1);
for times = 1: interFS

    beta_temp = beta;
    order = interOrder{cast(mod(times-1, 8), "uint8") + 1};
    for i = order(1): order(2): order(3)
        for j = order(4): order(5): order(6)
            for k = order(7): order(8): order(9)

                % upwind
                if abs(betax(i, j, k))>schemeTol || abs(betay(i, j, k))>schemeTol || abs(betaz(i, j, k))>schemeTol
    
                    if Tx(i, j, k) >= 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) >= 0
                        beta(i, j, k) = (Tx(i, j, k)*beta(i, j-1, k) + Ty(i, j, k)*beta(i-1, j, k) + Tz(i, j, k)*beta(i, j, k-1)) / (Tx(i, j, k) + Ty(i, j, k) +Tz(i, j, k) + eps);
                    end
                    if Tx(i, j, k) >= 0 && Ty(i, j, k) < 0 && Tz(i, j, k) >= 0
                        beta(i, j, k) = (Tx(i, j, k)*beta(i, j-1, k) - Ty(i, j, k)*beta(i+1, j, k) + Tz(i, j, k)*beta(i, j, k-1)) / (Tx(i, j, k) - Ty(i, j, k) +Tz(i, j, k) + eps);
                    end
                    if Tx(i, j, k) < 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) >= 0
                        beta(i, j, k) = (-Tx(i, j, k)*beta(i, j+1, k) + Ty(i, j, k)*beta(i-1, j, k) + Tz(i, j, k)*beta(i, j, k-1)) / (-Tx(i, j, k) + Ty(i, j, k) + Tz(i, j, k) + eps);
                    end
                    if Tx(i, j, k) < 0 && Ty(i, j, k) < 0 && Tz(i, j, k) >= 0
                        beta(i, j, k) = (-Tx(i, j, k)*beta(i, j+1, k) - Ty(i, j, k)*beta(i+1, j, k) + Tz(i, j, k)*beta(i, j, k-1)) / (-Tx(i, j, k) - Ty(i, j, k) + Tz(i, j, k) + eps);
                    end
                    if Tx(i, j, k) >= 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) < 0
                        beta(i, j, k) = (Tx(i, j, k)*beta(i, j-1, k) + Ty(i, j, k)*beta(i-1, j, k) - Tz(i, j, k)*beta(i, j, k+1)) / (Tx(i, j, k) + Ty(i, j, k) - Tz(i, j, k) + eps);
                    end
                    if Tx(i, j, k) >= 0 && Ty(i, j, k) < 0 && Tz(i, j, k) < 0
                        beta(i, j, k) = (Tx(i, j, k)*beta(i, j-1, k) - Ty(i, j, k)*beta(i+1, j, k) - Tz(i, j, k)*beta(i, j, k+1)) / (Tx(i, j, k) - Ty(i, j, k) - Tz(i, j, k) + eps);
                    end
                    if Tx(i, j, k) < 0 && Ty(i, j, k) >= 0 && Tz(i, j, k) < 0
                        beta(i, j, k) = (-Tx(i, j, k)*beta(i, j+1, k) + Ty(i, j, k)*beta(i-1, j, k) - Tz(i, j, k)*beta(i, j, k+1)) / (-Tx(i, j, k) + Ty(i, j, k) - Tz(i, j, k) + eps);
                    end
                    if Tx(i, j, k) < 0 && Ty(i, j, k) < 0 && Tz(i, j, k) < 0
                        beta(i, j, k) = (-Tx(i, j, k)*beta(i, j+1, k) - Ty(i, j, k)*beta(i+1, j, k) - Tz(i, j, k)*beta(i, j, k+1)) / (-Tx(i, j, k) - Ty(i, j, k) - Tz(i, j, k) + eps);
                    end
    
                % Lax-WENO   
                else
                    [betay_minus, betay_plus] = WENO_3(beta(i-2, j, k), beta(i-1, j, k), beta(i, j, k), beta(i+1, j, k), beta(i+2, j, k), h);
                    [betax_minus, betax_plus] = WENO_3(beta(i, j-2, k), beta(i, j-1, k), beta(i, j, k), beta(i, j+1, k), beta(i, j+2, k), h); 
                    [betaz_minus, betaz_plus] = WENO_3(beta(i, j, k-2), beta(i, j, k-1), beta(i, j, k), beta(i, j, k+1), beta(i, j, k+2), h); 
            
                    beta(i, j, k) = (h/(alphax + alphay + alphaz)) * ( - (betax_minus+betax_plus)*Tx(i, j, k) / 2 - (betay_minus+betay_plus) *Ty(i, j, k) / 2 - (betaz_minus+betaz_plus) *Tz(i, j, k) / 2 + ...
                        alphax*(betax_plus-betax_minus)/2 + alphay*(betay_plus-betay_minus)/2 + alphaz*(betaz_plus-betaz_minus)/2) + beta(i, j, k);
                end
              
            end
        end
    end
    
    inter_error(times) = max(abs(beta(:) - beta_temp(:)));
    if inter_error(times) < tolFS
        break;
    end
end