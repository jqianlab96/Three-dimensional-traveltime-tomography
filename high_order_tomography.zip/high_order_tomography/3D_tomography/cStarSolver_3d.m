function cstar = cStarSolver_3d(T, T_star, h, c)

    [I, J, K] = size(T);
    beta = highOrderLambdaSolver_3d(T, T_star, h);

    cstar = -beta ./ c.^3;
    niu = 1;
    cstar = c_solver2_3d(zeros(I, J, K), cstar, h, niu);
 
end
