function [fx, fy, fz] = weno_gradient_3d(f, dx, dy, dz)

[I, J, K] = size(f);
[fx, fy, fz] = gradient(f, dx, dy, dz);

for i = 4:I-3
    for j = 4:J-3
        for k = 4:K-3
        
            [fy_minus, fy_plus] = WENO_5(f(i-3, j, k), f(i-2, j, k), f(i-1, j, k), f(i, j, k), f(i+1, j, k), f(i+2, j, k), f(i+3, j, k), dy);
            [fx_minus, fx_plus] = WENO_5(f(i, j-3, k), f(i, j-2, k), f(i, j-1, k), f(i, j, k), f(i, j+1, k), f(i, j+2, k), f(i, j+3, k), dx);
            [fz_minus, fz_plus] = WENO_5(f(i, j, k-3), f(i, j, k-2), f(i, j, k-1), f(i, j, k), f(i, j, k+1), f(i, j, k+2), f(i, j, k+3), dz);
            fx(i, j, k) = (fx_minus+fx_plus)/2;
            fy(i, j, k) = (fy_minus+fy_plus)/2;
            fz(i, j, k) = (fz_minus+fz_plus)/2;

        end
    end
end